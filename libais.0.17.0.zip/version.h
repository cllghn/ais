#define PKG_NAME "libais"
#define PKG_VERSION "0.17.0"
