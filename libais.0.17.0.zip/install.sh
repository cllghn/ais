str=$(<version.h)
if [[ $str =~ .*NAME[^\"]+\"([^\"]+)\" ]]; then
    PKG=${BASH_REMATCH[1]}
    DPATH=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
    cd "$DPATH"
    if [ -e requirements.txt ]; then
      pip install $PKG -f dist -r requirements.txt
    fi
    pip install $PKG --force --no-deps -f dist
else
    echo "unable to parse version.h"
fi

